import java.util.*;
// public class largesmall {
//     public static int largest(int number[]) {
//     int largest=Integer.MIN_VALUE;
//     int smallest=Integer.MAX_VALUE;

//         for(int i=0; i<=number.length; i++){
//             if(largest < number[i]){
//                 largest = number[i];

//             }
//         }
//         return largest;
        
//     }

//     public static void main(String[] args) {
//         int number[]={1,5,4,6,};
//         largest(number);

//     }
//     }

        // CODING NINJAS PROBLEM


import java.util.* ;
import java.io.*; 

public class largesmall {

    static int largestElement(int[] arr, int n) {
        // Write your code here.
        int largest=arr[0];

        for(int i=0;i<n; i++){
            if(largest<arr[i]){
                largest=arr[i];
            }
        }
            return largest;
    }
    public static void main(String[] args) {
                 int number[]={1,5,4,6,};
                 int n=5;
                largestElement(number, n);
        
             }
            }