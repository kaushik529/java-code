else{
                System.out.println("Element not exist in the array");
            }