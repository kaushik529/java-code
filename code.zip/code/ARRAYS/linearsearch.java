public class linearsearch {

    public static int linear(int arr[], int target) {
        if (arr.length == 0) {
            return -1;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int arr[] = { 28, 29, 14, 33, 1, 2 };
        int target = 33;
        int ans = linear(arr, target);
        System.out.println(" The target is at index no:" + ans);
    }

}