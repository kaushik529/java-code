public class minmax {
    public static int max(int arr[]) {
        int maxVal= arr[0]; 
        for( int i=0; i<arr.length;i++){
            if(arr[i]>maxVal){
                maxVal=arr[i];
            }
        }
        return maxVal;
        
    }

public static int min(int arr[]) {
        int minVal= arr[0]; 
        for( int i=0; i<arr.length;i++){
            if(arr[i]<minVal){
                minVal=arr[i];
            }
        }
        return minVal;
        
    }

    public static void main(String[] args) {
        int arr[]= {23,25,66,99,88};


        System.err.println(max(arr));
        System.err.println(min(arr));
    }
    
}
