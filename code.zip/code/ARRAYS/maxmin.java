public class maxmin {

    public static int min(int arr[], int n) {
        int min= Integer.MAX_VALUE;
        
        // minimum element in array
        for(int i=0; i< n; i++){
            if(arr[i]<min){
                min=arr[i];
            }
        }
        return min;
    }
        // maximum element in array
        public static int max(int arr[], int n) {
            
            int max= Integer.MIN_VALUE;
            for(int i=0; i< n; i++){
            if(arr[i]>max){
                max=arr[i];
            }
        }
        return max;
    }
    
    public static void main(String[] args) {
        int arr[]={2,5,7,8};
        int n=arr.length;
        System.out.println("maximum is:"+ max(arr, n));
        System.out.println("minimum is:"+ min(arr, n));

    }
}
