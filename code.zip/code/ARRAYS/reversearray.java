public class reversearray {
    static void rvereseArray(int arr[],     int start, int end){

        while(start< end){
            int temp= arr[start];
            arr[start]=arr[end];
            arr[end]=temp;
            start ++;
            end --;
        }

    }         
    


    public static void main(String[] args) {
        int arr[]={11,12,13,14,15,16};
        for(int i=0; i<arr.length; i++){
        System.out.println(arr[i] + " ");
        }

        rvereseArray(arr, 11, 16);

        }
    
}
