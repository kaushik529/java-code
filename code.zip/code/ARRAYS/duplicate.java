public class duplicate {
    public static void dupli(int arr[]){
        for(int i=0; i<arr.length; i++)
        {
            for(int j=i+1; j<arr.length -1 ; i++){
                if(arr[i]==arr[j]){
                System.err.println(arr[i]);
                }
            }
        }
    }
    public static void main(String[] args) {
        int arr[]={1,1,2};
        dupli(arr);
    }
    
}
