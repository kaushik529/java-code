public class maxsubarrsum {
    public static void maxsum(int arr[]) {
        int currsum=0;
        int maxsum=Integer.MIN_VALUE;

        for(int i=0; i<arr.length; i++){
            int start =i;
            for(int j=i+1; j<arr.length; j++){
                int end =j;
                currsum=0;
                for(int k=start; k<= end ;k++){
                    currsum +=arr[k];
                }
                System.out.println(currsum);
                if(maxsum < currsum){
                    maxsum  = currsum;
                }
            }
        }
        System.err.println("The maxsum is :" + maxsum);
    }
    public static void main(String[] args) {
        int arr[]={1,-2,6,-1,3};
        maxsum(arr);
    }
    
}
